package com.example.escshop.Model;

import java.io.Serializable;

public class ViewAllModel implements Serializable {

    String name, price, type, img_url, rate, des, totalprice;

    public ViewAllModel() {
    }

    public ViewAllModel(String name, String price, String type, String img_url, String rate, String des, String totalprice) {
        this.name = name;
        this.price = price;
        this.type = type;
        this.img_url = img_url;
        this.rate = rate;
        this.des = des;
        this.totalprice = totalprice;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getImg_url() {
        return img_url;
    }

    public void setImg_url(String img_url) {
        this.img_url = img_url;
    }

    public String getRate() {
        return rate;
    }

    public void setRate(String rate) {
        this.rate = rate;
    }

    public String getDes() {
        return des;
    }

    public void setDes(String des) {
        this.des = des;
    }

    public String getTotalprice() {
        return totalprice;
    }

    public void setTotalprice(String totalprice) {
        this.totalprice = totalprice;
    }
}
