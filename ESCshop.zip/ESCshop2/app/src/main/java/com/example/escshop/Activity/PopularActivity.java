package com.example.escshop.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.Image;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.escshop.Model.PopularModel;
import com.example.escshop.Model.ViewAllModel;
import com.example.escshop.R;
import com.google.firebase.firestore.FirebaseFirestore;

public class PopularActivity extends AppCompatActivity {

    PopularModel popularModel = null;
    ImageView imageView;
    FirebaseFirestore firestore;
    int totalQuantity = 0;
    ImageView goback;
    TextView name, des;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_popular);

        final Object object = getIntent().getSerializableExtra("detail");
        if(object instanceof PopularModel){
            popularModel = (PopularModel) object;
        }

        firestore = FirebaseFirestore.getInstance();
        goback = findViewById(R.id.gobackpop);
        imageView = findViewById(R.id.rogpop);
        des = findViewById(R.id.descpop);
        name = findViewById(R.id.titleTxtpop);

        goback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MainActivity mainActivity = (MainActivity) getParent();
                if (mainActivity != null) {
                    mainActivity.updateCartItemCount(totalQuantity); // Pass the current cart size
                }

                // Add any other code for navigating back or other actions
                finish();
            }
        });

        if(popularModel != null){
            Glide.with(getApplicationContext()).load(popularModel.getImg_url()).into(imageView);
            des.setText(popularModel.getDes());
            name.setText(popularModel.getName());
        }


    }
}