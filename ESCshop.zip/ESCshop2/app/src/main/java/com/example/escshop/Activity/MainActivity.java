package com.example.escshop.Activity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.Menu;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.escshop.MyCartFragment;
import com.example.escshop.R;
import com.example.escshop.ui.home.HomeFragment;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.annotations.Nullable;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.fragment.NavHostFragment;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;
import androidx.appcompat.app.AppCompatActivity;

import de.hdodenhof.circleimageview.CircleImageView;


public class MainActivity extends AppCompatActivity {
    FirebaseAuth auth;
    TextView cartTextView;
    NavController navController;
    FirebaseFirestore firestore;
    FirebaseUser currentUser;
    FirebaseStorage storage;
    Button logout;
    MenuItem menuItem;
    private AppBarConfiguration mAppBarConfiguration;
    int totalQuantity = 0;

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        mAppBarConfiguration = new AppBarConfiguration.Builder(R.id.nav_home, R.id.nav_profile, R.id.nav_myorder, R.id.nav_mycart)
                .setDrawerLayout(drawer)
                .build();
        navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
        NavigationUI.setupActionBarWithNavController(this, navController, mAppBarConfiguration);
        NavigationUI.setupWithNavController(navigationView, navController);

        View headerView = navigationView.getHeaderView(0);
        TextView headerEmail = headerView.findViewById(R.id.emaildrawer);
        CircleImageView headerImg = headerView.findViewById(R.id.profileimg);

        logout = headerView.findViewById(R.id.logoutbutton);
        firestore = FirebaseFirestore.getInstance();
        auth = FirebaseAuth.getInstance();
        String fragmentToNavigateTo = getIntent().getStringExtra("fragmentToNavigateTo");

        if (fragmentToNavigateTo != null) {
            switch (fragmentToNavigateTo) {
                case "OrderFragment":
                    NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
                    navController.navigate(R.id.nav_myorder);


                    break;
            }
        }
        if (fragmentToNavigateTo != null) {
            switch (fragmentToNavigateTo) {
                case "CartFragment":
                    NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
                    navController.navigate(R.id.nav_mycart);
                    break;
            }
        }
        if (fragmentToNavigateTo != null) {
            switch (fragmentToNavigateTo) {
                case "HomeFragment":
                    NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
                    navController.navigate(R.id.nav_home);
                    break;
            }
        }

        if (fragmentToNavigateTo != null) {
            switch (fragmentToNavigateTo) {
                case "ProfileFragment":
                    NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
                    navController.navigate(R.id.nav_profile);
                    break;
            }
        }


        firestore.collection("CurrentUser").document(auth.getCurrentUser().getUid())
                .collection("AddToCart").get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()){
                            int cartSize = task.getResult().size();
                            if(cartTextView != null){
                                cartTextView.setText(String.valueOf(cartSize));
                            }else{
                                Log.e("Firestore", "Error retrieving the cart items: ", task.getException());
                            }
                            }
                        }
                });

        //get all cart items
        CollectionReference cartRef = firestore.collection("CurrentUser")
                .document(auth.getCurrentUser().getUid())
                .collection("AddToCart");

        // Add a real-time listener to the "AddToCart" collection
        cartRef.addSnapshotListener(new EventListener<QuerySnapshot>() {
            @Override
            public void onEvent(@Nullable QuerySnapshot querySnapshot, @Nullable FirebaseFirestoreException e) {
                if (e != null) {
                    // Handle any errors here
                    Log.e("Firebase", "Listen failed: " + e);
                    return;
                }

                if (querySnapshot != null) {
                    // Get the new cart size
                    int newCartSize = querySnapshot.size();

                    // Update the cartTextView with the new size
                    if (cartTextView != null) {
                        cartTextView.setText(String.valueOf(newCartSize));

                    }
                }
            }
        });

        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                // Handle navigation item clicks here
                int id = item.getItemId();

                if (id == R.id.nav_home) {
                    navController.navigate(R.id.nav_home);
                } else if (id == R.id.nav_profile){
                    navController.navigate(R.id.nav_profile);
                } else if (id == R.id.nav_myorder){
                    navController.navigate(R.id.nav_myorder);
                } else if (id == R.id.nav_mycart){
                    navController.navigate(R.id.nav_mycart);
                }

                // Close the drawer after handling the item click
                drawer.closeDrawer(GravityCompat.START);

                return true;
            }
        });


        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Create an AlertDialog for confirmation
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setTitle("Log Out");
                builder.setMessage("Are you sure you want to log out?");

                // Add a positive button (OK) to confirm the logout
                builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        // Sign out the user
                        auth.signOut();

                        // Redirect to the login activity
                        Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                        startActivity(intent);
                        finish(); // Close the current activity to prevent going back to it with the back button
                    }
                });

                // Add a negative button (Cancel) to dismiss the dialog
                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        // Dismiss the dialog
                        dialogInterface.dismiss();
                    }
                });

                // Create and show the AlertDialog
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });


        auth = FirebaseAuth.getInstance();
        firestore = FirebaseFirestore.getInstance();
        currentUser = auth.getCurrentUser();
        storage = FirebaseStorage.getInstance();


        if (currentUser != null) {
            String userEmail = currentUser.getEmail();
            headerEmail.setText(userEmail);

            StorageReference profileImageRef = storage.getReference()
                    .child("profile_picture")
                    .child(FirebaseAuth.getInstance().getUid());

            profileImageRef.getDownloadUrl().addOnSuccessListener(uri -> {
                // Use Glide to load and display the image
                Glide.with(MainActivity.this)
                        .load(uri)
                        .into(headerImg);
            }).addOnFailureListener(e -> {

            });
        }

        }


    public void updateCartItemCount(int itemCount) {
        // Update the cart item count in the UI (e.g., cartTextView)
        if (cartTextView != null) {
            cartTextView.setText(String.valueOf(itemCount));
        }
    }




        @Override
        public boolean onCreateOptionsMenu (Menu menu){
            // Inflate the menu; this adds items to the action bar if it is present.
            getMenuInflater().inflate(R.menu.main, menu);
            menuItem = menu.findItem(R.id.MyCartFragment);
            View actionView = menuItem.getActionView();

            cartTextView = actionView.findViewById(R.id.cartTextView);

            actionView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    // Navigate to the MyCartFragment using NavController
                    navController.navigate(R.id.nav_mycart);
                }
            });


            return true;
        }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        return super.onOptionsItemSelected(item) || NavigationUI.onNavDestinationSelected(item, navController);
    }

    @Override
        public boolean onSupportNavigateUp () {
            NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
            return NavigationUI.navigateUp(navController, mAppBarConfiguration)
                    || super.onSupportNavigateUp();
        }
    }
