package com.example.escshop.Model;

import java.io.Serializable;

public class PopularModel implements Serializable {
    String name, des, img_url;
    public PopularModel() {
    }

    public PopularModel(String name, String des, String img_url) {
        this.name = name;
        this.des = des;
        this.img_url = img_url;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDes() {
        return des;
    }

    public void setDes(String des) {
        this.des = des;
    }

    public String getImg_url() {
        return img_url;
    }

    public void setImg_url(String img_url) {
        this.img_url = img_url;
    }
}
