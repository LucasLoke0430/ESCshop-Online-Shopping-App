package com.example.escshop.Adapter;

import android.content.Context;
import android.widget.ArrayAdapter;
import android.widget.Filter;
import android.widget.Filterable;

import androidx.annotation.NonNull;

import com.example.escshop.Model.PlaceModel;

import java.util.ArrayList;

public class PlaceAutoSuggestAdapter extends ArrayAdapter implements Filterable {

    ArrayList<String> result;
    int resource;
    Context context;
    PlaceModel placeModel = new PlaceModel();
    public PlaceAutoSuggestAdapter(Context context, int resId){
        super(context, resId);
        this.context=context;
        this.resource=resId;
    }

    @Override
    public int getCount(){
        return result.size();
    }

    @Override
    public String getItem(int pos){
        return result.get(pos);
    }

    @NonNull
    @Override
    public Filter getFilter() {
        Filter filter = new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence constraint) {
                FilterResults filterResults = new FilterResults();
                if (constraint != null) {
                    result = placeModel.autoComplete(constraint.toString());

                    filterResults.values = result;
                    filterResults.count= result.size();
                }
                return filterResults;
            }

            @Override
            protected void publishResults(CharSequence constriant, FilterResults filterResults) {
                if(filterResults !=null && filterResults.count>0){
                    notifyDataSetChanged();
                }else {
                    notifyDataSetInvalidated();
                }

            }
        };
        return filter;
    }


}
