package com.example.escshop.ui.profile;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.fragment.NavHostFragment;

import com.bumptech.glide.Glide;
import com.example.escshop.Activity.MainActivity;
import com.example.escshop.R;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import de.hdodenhof.circleimageview.CircleImageView;

public class ProfileFragment extends Fragment {

    CircleImageView profilepic;
    EditText profileemail,profileaddress,profilephone;
    Button update;
    ImageView goback;

    FirebaseStorage storage;
    FirebaseAuth auth;
    FirebaseDatabase database;
    NavController navController;
    LinearLayout home, cart, order, profile;

    private ActivityResultLauncher<Intent> imagePickerLauncher;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        View root = inflater.inflate(R.layout.fragment_profile, container, false);

        auth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();
        storage = FirebaseStorage.getInstance();
        navController = NavHostFragment.findNavController(this);

        profilepic = root.findViewById(R.id.profilepic);
        profileemail = root.findViewById(R.id.profile_email);
        profileaddress = root.findViewById(R.id.profile_address);
        profilephone = root.findViewById(R.id.profile_phone);
        update = root.findViewById(R.id.update);
        goback = root.findViewById(R.id.profilebackBtn);
        navController = NavHostFragment.findNavController(ProfileFragment.this);
        home = root.findViewById(R.id.homeBtn);
        cart = root.findViewById(R.id.cartBtn);
        order = root.findViewById(R.id.orderBtn);
        profile = root.findViewById(R.id.profileBtn);

        goback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Use the FragmentManager to navigate back to the previous fragment
                NavHostFragment.findNavController(ProfileFragment.this).navigate(R.id.nav_home);
            }
        });

        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navController.navigate(R.id.nav_home);
            }
        });

        cart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navController.navigate(R.id.nav_mycart);
            }
        });

        order.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navController.navigate(R.id.nav_myorder);
            }
        });

        profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navController.navigate(R.id.nav_profile);
            }
        });

        // Initialize the imagePickerLauncher
        imagePickerLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == Activity.RESULT_OK) {
                        Intent data = result.getData();
                        if (data != null) {
                            Uri profileUri = data.getData();
                            profilepic.setImageURI(profileUri);

                            final StorageReference reference = storage.getReference()
                                    .child("profile_picture")
                                    .child(FirebaseAuth.getInstance().getUid());

                            reference.putFile(profileUri)
                                    .addOnSuccessListener(taskSnapshot -> {
                                        // Image upload successful, get the download URL
                                        reference.getDownloadUrl().addOnSuccessListener(uri -> {
                                            // Update the user's profile with the new image URL
                                            String imageUrl = uri.toString();
                                            updateProfileImageUrl(imageUrl);
                                        }).addOnFailureListener(e -> {
                                            // Handle the failure to get the download URL
                                        });
                                    })
                                    .addOnFailureListener(e -> {
                                        // Handle the image upload failure
                                    });
                        }
                    }
                });

        // Load the user's profile picture from Firebase Storage
        loadUserProfilePicture();
        fetchUserProfileData();

        profilepic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Create an intent to pick an image
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType("image/*");
                // Launch the image picker using the ActivityResultLauncher
                imagePickerLauncher.launch(intent);
            }
        });

                update.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        // Get the updated values from the EditText fields
                        String updatedEmail = profileemail.getText().toString();
                        String updatedAddress = profileaddress.getText().toString();
                        String updatedPhone = profilephone.getText().toString().trim();

                        if (!isValidMalaysiaPhoneNumber(updatedPhone)) {
                            Toast.makeText(getContext(), "Invalid phone number format", Toast.LENGTH_SHORT).show();
                            return;
                        }else {
                            Toast.makeText(getContext(), "Profile information updated", Toast.LENGTH_SHORT).show();
                        }
                        DatabaseReference userRef = database.getReference("Users").child(auth.getCurrentUser().getUid());
                        userRef.child("email").setValue(updatedEmail);
                        userRef.child("name").setValue(updatedAddress);
                        userRef.child("phone").setValue(updatedPhone);

                        navController.navigate(R.id.nav_home);

                    }
                });

        return root;
    }

    public boolean isValidMalaysiaPhoneNumber(String phoneNumber) {

        String regex = "^01\\d{9}|01\\d{8}$";


        return phoneNumber.matches(regex);
    }
    private void fetchUserProfileData() {
        DatabaseReference userRef = database.getReference("Users").child(auth.getCurrentUser().getUid());
        userRef.get().addOnSuccessListener(snapshot -> {
            if (snapshot.exists()) {
                // Fetch and populate user data
                String userEmail = snapshot.child("email").getValue(String.class);
                String userAddress = snapshot.child("name").getValue(String.class);
                String userPhone = snapshot.child("phone").getValue(String.class);

                // Populate the EditText fields with user data
                profileemail.setText(userEmail);
                profileaddress.setText(userAddress);
                profilephone.setText(userPhone);
            }
        }).addOnFailureListener(e -> {
            // Handle the failure to fetch user data
        });
    }

    // Method to update the user's profile with the new image URL
    private void updateProfileImageUrl(String imageUrl) {
        // Update the user's profile data (e.g., in Firebase Realtime Database or Firestore)
        // For example, you can update the user's profile data in Firebase Realtime Database like this:
        DatabaseReference userRef = database.getReference("Users").child(auth.getCurrentUser().getUid());
        userRef.child("profileImageUrl").setValue(imageUrl)
                .addOnSuccessListener(aVoid -> {
                    Toast.makeText(getContext(), "Profile picture updated", Toast.LENGTH_SHORT).show();
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(getContext(), "Failed to update profile picture", Toast.LENGTH_SHORT).show();
                });
    }

    // Method to load the user's profile picture from Firebase Storage and display it using Glide
    private void loadUserProfilePicture() {
        // Load the user's profile picture from Firebase Storage
        StorageReference profileImageRef = storage.getReference()
                .child("profile_picture")
                .child(FirebaseAuth.getInstance().getUid());

        profileImageRef.getDownloadUrl().addOnSuccessListener(uri -> {
            // Use Glide to load and display the image
            Glide.with(requireContext())
                    .load(uri)
                    .into(profilepic);
        }).addOnFailureListener(e -> {
        });
    }
}