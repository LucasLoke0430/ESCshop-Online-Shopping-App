package com.example.escshop;

import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import androidx.navigation.NavController;
import androidx.navigation.fragment.NavHostFragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.escshop.Activity.DetailedActivity;
import com.example.escshop.Activity.MainActivity;
import com.example.escshop.Activity.MapActivity;
import com.example.escshop.Activity.PlaceOrderActivity;
import com.example.escshop.Adapter.MyCartAdapter;
import com.example.escshop.Model.MyCartModel;
import com.example.escshop.Model.OrderModel;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.annotations.Nullable;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.protobuf.StringValue;

import org.w3c.dom.Text;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class MyCartFragment extends Fragment {


    FirebaseFirestore db;
    FirebaseAuth auth;
    RecyclerView recyclerView;
    MyCartAdapter myCartAdapter;
    List<MyCartModel> myCartModelList;
    TextView overTotalAmount, deliveryFee, grandTotal;
    Spinner paymentmethod;
    ImageView goback, addressbtn;
    Button buynow;
    TextView address;
    String method;
    ImageView maps;
    LinearLayout home, cart, order, profile;
    NavController navController;
    List<OrderModel> orderModel;

    public MyCartFragment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View root = inflater.inflate(R.layout.fragment_my_cart, container, false);

        db = FirebaseFirestore.getInstance();
        auth = FirebaseAuth.getInstance();
        recyclerView = root.findViewById(R.id.cartrecycleview);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        navController = NavHostFragment.findNavController(this);


        goback = root.findViewById(R.id.backBtn);
        deliveryFee = root.findViewById(R.id.deliveryTxt);
        overTotalAmount = root.findViewById(R.id.totalFeeTxt);
        grandTotal = root.findViewById(R.id.totalTxt);
        buynow = root.findViewById(R.id.buynow);
        address = root.findViewById(R.id.textView24);
        addressbtn = root.findViewById(R.id.imageView11);
        paymentmethod = root.findViewById(R.id.textView26);
        maps = root.findViewById(R.id.imageView10);
        home = root.findViewById(R.id.homeBtn1);
        cart = root.findViewById(R.id.cartBtn1);
        order = root.findViewById(R.id.orderBtn1);
        profile = root.findViewById(R.id.profileBtn1);



        goback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Use the FragmentManager to navigate back to the previous fragment
                NavHostFragment.findNavController(MyCartFragment.this).navigate(R.id.nav_home);
            }
        });

        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navController.navigate(R.id.nav_home);
            }
        });

        cart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navController.navigate(R.id.nav_mycart);
            }
        });

        order.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navController.navigate(R.id.nav_myorder);
            }
        });

        profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navController.navigate(R.id.nav_profile);
            }
        });

        myCartModelList = new ArrayList<>();
        myCartAdapter = new MyCartAdapter(getActivity(), myCartModelList, NavHostFragment.findNavController(this) );
        recyclerView.setAdapter(myCartAdapter);


        //show user address
        CollectionReference addressCollection = db.collection("CurrentUser")
                .document(auth.getCurrentUser().getUid())
                .collection("Address");

        addressCollection
                .get()
                .addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                    @Override
                    public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                        if (!queryDocumentSnapshots.isEmpty()) {
                            // Get the first document (assuming there's only one)
                            DocumentSnapshot addressDocument = queryDocumentSnapshots.getDocuments().get(0);

                            // Retrieve the address field
                            String userAddress = addressDocument.getString("name");

                            // Display the address in the EditText
                            address.setText(userAddress);
                        } else {
                            // Handle the case where the user doesn't have an address document
                        }
                    }
                });


        // Listen for changes to the 'totalPrice' field in Firestore
        db.collection("CurrentUser").document(auth.getCurrentUser().getUid())
                .collection("AddToCart")
                .addSnapshotListener(new EventListener<QuerySnapshot>() {
                    @Override
                    public void onEvent(@Nullable QuerySnapshot value, @Nullable FirebaseFirestoreException error) {
                        if (error != null) {
                            // Handle the error here
                            return;
                        }

                        // Calculate the total price and update the UI
                        double total = calculateTotalPrice(value);
                        updateUI(total);
                    }
                });


        db.collection("CurrentUser").document(auth.getCurrentUser().getUid())
                .collection("AddToCart").get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (DocumentSnapshot documentSnapshot : task.getResult().getDocuments()) {
                                String documentId = documentSnapshot.getId();

                                MyCartModel cartModel = documentSnapshot.toObject(MyCartModel.class);
                                cartModel.setDocumentId(documentId);
                                myCartModelList.add(cartModel);
                                myCartAdapter.notifyDataSetChanged();
                            }

                            // Now that myCartModelList is populated, check if it contains non-service items
                            boolean containsNonServiceItem = false;
                            for (MyCartModel cartItem : myCartModelList) {
                                if (!"services".equalsIgnoreCase(cartItem.getType())) {
                                    containsNonServiceItem = true;
                                    break;
                                }
                            }

                            // Enable or disable address and maps based on containsNonServiceItem
                            if (containsNonServiceItem) {
                                // There are non-service items in the cart, enable address and maps
                                address.setEnabled(true);
                                addressbtn.setEnabled(true);
                                maps.setEnabled(true);
                                address.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View view) {
                                        // Handle address click for non-service items
                                        Intent intent = new Intent(getContext(), MapActivity.class);
                                        startActivity(intent);
                                    }
                                });
                                addressbtn.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View view) {
                                        // Handle address click for non-service items
                                        Intent intent = new Intent(getContext(), MapActivity.class);
                                        startActivity(intent);
                                    }
                                });
                                maps.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View view) {
                                        // Handle address click for non-service items
                                        Intent intent = new Intent(getContext(), MapActivity.class);
                                        startActivity(intent);
                                    }
                                });
                            } else if (myCartModelList.isEmpty()){
                                // The cart only contains service items, set the address to "ESCshop"
                                address.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View view) {
                                        Intent intent = new Intent(getContext(), MapActivity.class);
                                        startActivity(intent);
                                    }
                                });
                                addressbtn.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View view) {
                                        Intent intent = new Intent(getContext(), MapActivity.class);
                                        startActivity(intent);
                                    }
                                });
                                maps.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View view) {
                                        Intent intent = new Intent(getContext(), MapActivity.class);
                                        startActivity(intent);
                                    }
                                });
                            }else if (!containsNonServiceItem){
                                address.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View view) {
                                        Intent intent = new Intent(getContext(), MapActivity.class);
                                        startActivity(intent);
                                    }
                                });
                                addressbtn.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View view) {
                                        Intent intent = new Intent(getContext(), MapActivity.class);
                                        startActivity(intent);
                                    }
                                });
                                maps.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View view) {
                                        Intent intent = new Intent(getContext(), MapActivity.class);
                                        startActivity(intent);
                                    }
                                });
                            }
                            calculateTotalAmount(myCartModelList);
                            myCartAdapter.notifyDataSetChanged();
                        }
                    }
                });

        //Spinner for payment method
        paymentmethod.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {
                method = adapterView.getItemAtPosition(position).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        ArrayList<String> arrayList = new ArrayList<>();
        arrayList.add("Please Select Your Payment Method");
        arrayList.add("Cash On Delivery");
        arrayList.add("Online Banking");
        arrayList.add("Credit / Debit Card");
        ArrayAdapter<String> adapter = new ArrayAdapter<>(getContext(), R.layout.custom_spinner_item, arrayList);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        paymentmethod.setAdapter(adapter);

        db.collection("CurrentUser")
                .document(auth.getCurrentUser().getUid())
                .collection("MyOrder")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                                           @Override
                                           public void onComplete(@NonNull Task<QuerySnapshot> task) {
                                               if (task.isSuccessful()) {
                                                   orderModel = new ArrayList<>();
                                                   for (QueryDocumentSnapshot document : task.getResult()) {
                                                       OrderModel order = document.toObject(OrderModel.class);
                                                       orderModel.add(order);
                                                   }
                                               }
                                           }
                                       });

        buynow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                boolean hasServicesOrder = hasServicesOrder(orderModel);
                boolean containsNonServiceItem = containsNonServiceItem(myCartModelList);

                if(containsNonServiceItem){
                    Intent intent = new Intent(getContext(), PlaceOrderActivity.class);
                    intent.putExtra("itemList", (Serializable) myCartModelList);
                    intent.putExtra("method", method);
                    intent.putExtra("userAddress", address.getText().toString());
                    if ("Please Select Your Payment Method".equals(method)) {
                        Toast.makeText(getContext(), "Please select a payment method", Toast.LENGTH_SHORT).show();
                    }else if(address.getText() == null || address.getText().toString().isEmpty()){
                        Toast.makeText(getContext(), "Enter an address", Toast.LENGTH_SHORT).show();
                    }else{
                        deleteAllCartItems();
                        startActivity(intent);
                    }



                } else if(myCartModelList.isEmpty()){
                    Toast.makeText(getContext(),"Unable to place an order when the cart is empty",Toast.LENGTH_SHORT).show();
                }else if ("Please Select Your Payment Method".equals(method)) {
                    // Show a toast message if the payment method is not selected
                    Toast.makeText(getContext(), "Please select a payment method", Toast.LENGTH_SHORT).show();
                }else if(address.getText() == null || address.getText().toString().isEmpty()){
                    Toast.makeText(getContext(), "Enter an address", Toast.LENGTH_SHORT).show();
                } else if (hasServicesOrder) {
                    Toast.makeText(getContext(), "You have a service product in your orders already", Toast.LENGTH_SHORT).show();
                }else{
                        deleteAllCartItems();
                        Intent intent = new Intent(getContext(), PlaceOrderActivity.class);
                        intent.putExtra("itemList", (Serializable) myCartModelList);
                        intent.putExtra("method", method);
                        intent.putExtra("userAddress", address.getText().toString());
                        startActivity(intent);
                    }
                }

        });

        return root;
    }

    private boolean containsNonServiceItem(List<MyCartModel> myCartModelList) {
        for (MyCartModel cartItem : myCartModelList) {
            if (!"services".equalsIgnoreCase(cartItem.getType())) {
                return true; // Found a non-service product in the cart
            }
        }
        return false; // No non-service product found in the cart
    }
    private boolean hasServicesOrder(List<OrderModel> orderModelList) {
        for (OrderModel order : orderModelList) {
            if ("services".equalsIgnoreCase(order.getType())) {
                return true; // Found a "services" order
            }
        }
        return false; // No "services" order found
    }

    private double calculateTotalPrice(QuerySnapshot value) {
        double total = 0.0;
        if (value != null) {
            for (DocumentSnapshot document : value.getDocuments()) {
                MyCartModel cartItem = document.toObject(MyCartModel.class);
                if (cartItem != null) {
                    try {
                        double itemTotalPrice = Double.parseDouble(cartItem.getTotalPrice());
                        total += itemTotalPrice;
                    } catch (NumberFormatException e) {
                        e.printStackTrace();
                    }
                }else {
                }
            }
        }

        return total;
    }

    private void deleteAllCartItems() {
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        CollectionReference cartItemsRef = db.collection("CurrentUser")
                .document(auth.getCurrentUser().getUid())
                .collection("AddToCart");

        cartItemsRef.get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (task.isSuccessful()) {
                    for (DocumentSnapshot document : task.getResult()) {
                        // Delete each cart item document
                        cartItemsRef.document(document.getId()).delete();
                    }
                    // Clear the list and notify the adapter
                    myCartModelList.clear();
                    myCartAdapter.notifyDataSetChanged();
                    // Calculate the total amount after clearing the cart
                    calculateTotalAmount(myCartModelList);
                } else {
                    // Handle the error
                }
            }
        });
    }

    private void updateUI(double total) {
        double grandTotalValue = 0;
        double deliveryFees = 0.0; // Set delivery fees based on cart items
        boolean containsNonServiceItem = false; // Check if there's a non-service item in the cart

        // Check if the cart contains a non-service item
        for (MyCartModel cartItem : myCartModelList) {
            if (!"services".equalsIgnoreCase(cartItem.getType())) {
                containsNonServiceItem = true;
                break; // Exit the loop if a non-service item is found
            }
        }

        // Set the delivery fee based on whether the cart contains non-service items
        if (containsNonServiceItem) {
            deliveryFees = 10;
        }

        grandTotalValue = total + deliveryFees;

        deliveryFee.setText("RM " + String.format("%.2f", deliveryFees));
        grandTotal.setText("RM " + String.format("%.2f", grandTotalValue));
        overTotalAmount.setText("RM " + String.format("%.2f", total));
        myCartAdapter.notifyDataSetChanged();
    }



    private void calculateTotalAmount(List<MyCartModel> myCartModelList) {
        double total = 0.0;
        double deliveryFees = 0.0;
        boolean containsNonServiceItem = false; // Check if there's a non-service item in the cart

        // Calculate the total price by summing up the 'totalPrice' field of each item
        for (MyCartModel cartItem : myCartModelList) {
            try {
                double itemTotalPrice = Double.parseDouble(cartItem.getTotalPrice());
                total += itemTotalPrice;

                // Check if the cart contains a non-service item
                if (!"services".equalsIgnoreCase(cartItem.getType())) {
                    containsNonServiceItem = true;
                }
            } catch (NumberFormatException e) {
                e.printStackTrace();
            }
        }

        // Set the delivery fee based on whether the cart contains non-service items
        if (containsNonServiceItem) {
            deliveryFees = 10;
        }

        // Calculate the grand total
        double grandTotalValue = total + deliveryFees;

        // Update the UI
        deliveryFee.setText("RM " + String.format("%.2f", deliveryFees));
        grandTotal.setText("RM " + String.format("%.2f", grandTotalValue));
        overTotalAmount.setText("RM " + String.format("%.2f", total));

        // Notify the adapter if needed (you might not need this line)
        myCartAdapter.notifyDataSetChanged();
    }




}