package com.example.escshop.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.escshop.Model.OrderModel;
import com.example.escshop.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import org.w3c.dom.Text;

import java.util.List;

public class OrderAdapter extends RecyclerView.Adapter<OrderAdapter.ViewHolder> {
    Context context;
    List<OrderModel> orderModelList;
    FirebaseFirestore firestore;
    FirebaseAuth auth;
    ImageView superman;
    ImageView progressbar;
    TextView deliverytext;
    OrderModel orderModel;

    public OrderAdapter(Context context, List<OrderModel> orderModelList, ImageView superman, ImageView progressbar, TextView deliverytext) {
        this.context = context;
        this.orderModelList = orderModelList;
        this.superman = superman;
        this.progressbar = progressbar;
        this.deliverytext = deliverytext;
        firestore = FirebaseFirestore.getInstance();
        auth = FirebaseAuth.getInstance();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.order_view,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        orderModel = orderModelList.get(position);
        String orderType = orderModel.getType();

        if ("services".equalsIgnoreCase(orderType)) {
            holder.orderprice.setVisibility(View.GONE);
            holder.orderquantity.setVisibility(View.GONE);

            Glide.with(context).load(orderModelList.get(position).getImg_url()).into(holder.img_url);
            holder.ordername.setText("Product Name: " + orderModelList.get(position).getProductName());
            holder.orderdate.setText("Date: " + orderModelList.get(position).getDate());
            holder.ordertime.setText("Time: " + orderModelList.get(position).getTime());
            holder.orderaddress.setText("Address: Walk In");
        }else {
            holder.orderprice.setVisibility(View.VISIBLE);
            holder.orderquantity.setVisibility(View.VISIBLE);
            Glide.with(context).load(orderModelList.get(position).getImg_url()).into(holder.img_url);
            holder.ordername.setText("Product Name: "+orderModelList.get(position).getProductName());
            holder.orderprice.setText("Price: "+orderModelList.get(position).getTotalPrice());
            holder.orderquantity.setText("Quantity: "+orderModelList.get(position).getTotalQuantity());
            holder.orderdate.setText("Date: "+orderModelList.get(position).getDate());
            holder.ordertime.setText("Time: "+orderModelList.get(position).getTime());
            holder.orderaddress.setText("Address: "+orderModelList.get(position).getUserAddress());
        }

        holder.cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                firestore.collection("CurrentUser").document(auth.getCurrentUser().getUid())
                        .collection("MyOrder")
                        .document(orderModelList.get(holder.getAdapterPosition()).getDocumentId())
                        .delete()
                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                if (task.isSuccessful()) {
                                    // Remove the order from the list
                                    orderModelList.remove(orderModelList.get(holder.getAdapterPosition()));
                                    notifyDataSetChanged();
                                    Toast.makeText(context, "Your order has been cancelled", Toast.LENGTH_SHORT).show();

                                    if (orderModelList.isEmpty()) {
                                        // No orders, set visibility to GONE
                                        superman.setVisibility(View.GONE);
                                        progressbar.setVisibility(View.GONE);
                                        deliverytext.setText("No Order Has Been Made Yet");
                                    } else {
                                        // Orders found, notify the adapter of the data change
                                        notifyDataSetChanged();
                                        superman.setVisibility(View.VISIBLE);
                                        progressbar.setVisibility(View.VISIBLE);
                                        deliverytext.setText("Preparing...");
                                    }
                                } else {
                                    Toast.makeText(context, "Cancel Unsuccessful", Toast.LENGTH_SHORT).show();
                                }
                            }
                        });
            }
        });

    }

    @Override
    public int getItemCount() {
        return orderModelList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView img_url;
        TextView ordername, orderprice, orderquantity, orderdate, ordertime, orderaddress;
        Button cancel;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            cancel = itemView.findViewById(R.id.cancelorder);
            img_url = itemView.findViewById(R.id.orderpic);
            ordername = itemView.findViewById(R.id.ordername);
            orderprice = itemView.findViewById(R.id.orderprice);
            orderquantity = itemView.findViewById(R.id.orderquantity);
            orderdate = itemView.findViewById(R.id.orderdate);
            ordertime = itemView.findViewById(R.id.ordertime);
            orderaddress = itemView.findViewById(R.id.orderaddress);
        }
    }
}
