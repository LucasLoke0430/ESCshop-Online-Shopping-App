package com.example.escshop.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;

import com.example.escshop.Model.MyCartModel;
import com.example.escshop.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class PlaceOrderActivity extends AppCompatActivity {


    FirebaseAuth auth;
    FirebaseFirestore firestore;
    List<MyCartModel> myCartModelList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_place_order);

        auth = FirebaseAuth.getInstance();
        firestore = FirebaseFirestore.getInstance();

        List<MyCartModel> list = (ArrayList<MyCartModel>) getIntent().getSerializableExtra("itemList");
        String method = getIntent().getStringExtra("method");
        String userAddress = getIntent().getStringExtra("userAddress");

        if(list != null && list.size() > 0){
            for (MyCartModel model: list){
                final HashMap<String, Object> cartMap = new HashMap<>();

                cartMap.put("img_url",model.getImg_url());
                cartMap.put("productName", model.getProductName());
                cartMap.put("Price", model.getPrice());
                cartMap.put("Date", model.getDate());
                cartMap.put("Time", model.getTime());
                cartMap.put("totalQuantity", model.getTotalQuantity());
                cartMap.put("totalPrice", model.getTotalPrice());
                cartMap.put("paymentMethod", method);
                cartMap.put("userAddress", userAddress);
                cartMap.put("type", model.getType());


                firestore.collection("CurrentUser").document(auth.getCurrentUser().getUid())
                        .collection("MyOrder").add(cartMap).addOnCompleteListener(new OnCompleteListener<DocumentReference>() {
                            @Override
                            public void onComplete(@NonNull Task<DocumentReference> task) {
                                // Wait for 3 seconds before redirecting
                                new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                                    @Override
                                    public void run() {

                                        String fragmentToNavigateTo = "OrderFragment";

                                        Intent intent = new Intent(PlaceOrderActivity.this, MainActivity.class);
                                        intent.putExtra("fragmentToNavigateTo", fragmentToNavigateTo);
                                        startActivity(intent);
                                        finish();
                                    }
                                }, 3000); // 3000 milliseconds = 3 seconds
                            }
                        });
            }
        }
    }
}