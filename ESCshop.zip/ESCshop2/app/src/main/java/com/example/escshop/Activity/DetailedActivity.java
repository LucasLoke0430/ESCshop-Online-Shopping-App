package com.example.escshop.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.escshop.Model.OrderModel;
import com.example.escshop.Model.PopularModel;
import com.example.escshop.Model.ViewAllModel;
import com.example.escshop.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;

public class DetailedActivity extends AppCompatActivity {

    ImageView imageView;
    TextView quantity;
    int totalQuantity = 0;
    int totalPrice = 0;
    TextView name,price,rate,des,totalprice;
    Button addTocart;
    TextView minus,plus;
    ImageView goback;
    ViewAllModel viewAllModel = null;
    OrderModel orderModel = null;

    FirebaseFirestore firestore;
    FirebaseAuth auth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detailed);

        final Object object = getIntent().getSerializableExtra("detail");
        if(object instanceof ViewAllModel){
            viewAllModel = (ViewAllModel) object;
        }

        firestore = FirebaseFirestore.getInstance();
        auth = FirebaseAuth.getInstance();

        totalprice = findViewById(R.id.totalprice);
        quantity = findViewById(R.id.numberItemTxt);
        goback = findViewById(R.id.goback);
        imageView = findViewById(R.id.rog);
        name = findViewById(R.id.titleTxt);
        price = findViewById(R.id.priceTxt);
        rate = findViewById(R.id.StarTxt);
        des = findViewById(R.id.descriptionTxt);

        addTocart = findViewById(R.id.addToCartBtn);
        minus = findViewById(R.id.MinusCartBtn);
        plus = findViewById(R.id.plusCardBtn);


        addTocart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addToCart();
            }
        });


        if(viewAllModel != null){
            Glide.with(getApplicationContext()).load(viewAllModel.getImg_url()).into(imageView);
            rate.setText(viewAllModel.getRate());
            name.setText(viewAllModel.getName());
            des.setText(viewAllModel.getDes());
            totalprice.setText(viewAllModel.getTotalprice());
            price.setText(viewAllModel.getPrice());
        }

        checkProductType();

        plus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(totalQuantity < 10){
                    totalQuantity++;
                    quantity.setText(String.valueOf(totalQuantity));

                    updateTotalPrice();
                }
            }
        });

        minus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(totalQuantity > 0){
                    totalQuantity--;
                    quantity.setText(String.valueOf(totalQuantity));


                    updateTotalPrice();
                }
            }
        });

        goback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MainActivity mainActivity = (MainActivity) getParent();
                if (mainActivity != null) {
                    mainActivity.updateCartItemCount(totalQuantity); // Pass the current cart size
                }

                // Add any other code for navigating back or other actions
                finish();
                }
        });

    }

    private void checkProductType() {
        if (viewAllModel != null) {
            String productType = viewAllModel.getType(); // Assuming you have a getType() method in your ViewAllModel class

            if ("services".equalsIgnoreCase(productType)) {
                disableButtonsForServicesProduct();
            } else {
                // The product's type is not "services"
                // Enable buttons or perform other actions
                enableButtonsForNonServicesProduct();
            }
        }
    }

    private void disableButtonsForServicesProduct() {
        // Disable specific buttons or perform actions for products with type "services"
        plus.setEnabled(false);
        minus.setEnabled(false);
    }

    private void enableButtonsForNonServicesProduct() {
        // Enable buttons or perform actions for products that are not of type "services"
        plus.setEnabled(true);
        minus.setEnabled(true);
    }



    private void addToCart() {
        String saveCurrentDate, saveCurrentTime;
        Calendar calForDate = Calendar.getInstance();

        SimpleDateFormat currentDate = new SimpleDateFormat("MM/dd/yyyy");
        saveCurrentDate = currentDate.format(calForDate.getTime());

        SimpleDateFormat currentTime = new SimpleDateFormat("HH:mm:ss a");
        saveCurrentTime = currentTime.format(calForDate.getTime());

        final HashMap<String, Object> cartMap = new HashMap<>();

        String productType = viewAllModel.getType();

        if ("services".equalsIgnoreCase(productType) && totalQuantity == 0){
            if (viewAllModel != null) {
                cartMap.put("img_url",viewAllModel.getImg_url());
                cartMap.put("productName", viewAllModel.getName());
            }

            cartMap.put("Price", price.getText().toString());
            cartMap.put("Date", saveCurrentDate);
            cartMap.put("Time", saveCurrentTime);
            cartMap.put("totalQuantity", quantity.getText().toString());
            cartMap.put("totalPrice", totalprice.getText().toString());
            cartMap.put("type",productType);

            firestore.collection("CurrentUser")
                    .document(auth.getCurrentUser().getUid())
                    .collection("AddToCart")
                    .whereEqualTo("productName", viewAllModel.getName())
                    .get()
                    .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<QuerySnapshot> task) {
                            if (task.isSuccessful()) {
                                boolean productExists = false;
                                for (QueryDocumentSnapshot document : task.getResult()) {
                                    // If the product exists in the cart, update its quantity
                                    productExists = true;
                                    int existingQuantity = Integer.parseInt(document.get("totalQuantity").toString());
                                    int newQuantity = existingQuantity + totalQuantity;
                                    if(newQuantity >= 0){
                                        Toast.makeText(DetailedActivity.this, "You can only reserve for one service", Toast.LENGTH_SHORT).show();
                                    }else {
                                        document.getReference().update("totalQuantity", String.valueOf(newQuantity))
                                                .addOnCompleteListener(new OnCompleteListener<Void>() {
                                                    @Override
                                                    public void onComplete(@NonNull Task<Void> task) {
                                                        Toast.makeText(DetailedActivity.this, "Added To Cart", Toast.LENGTH_SHORT).show();
                                                        finish();
                                                    }
                                                });
                                    }
                                }
                                if (!productExists) {
                                    firestore.collection("CurrentUser")
                                            .document(auth.getCurrentUser().getUid())
                                            .collection("AddToCart")
                                            .add(cartMap)
                                            .addOnCompleteListener(new OnCompleteListener<DocumentReference>() {
                                                @Override
                                                public void onComplete(@NonNull Task<DocumentReference> task) {
                                                    Toast.makeText(DetailedActivity.this, "Added To Cart", Toast.LENGTH_SHORT).show();
                                                    finish();
                                                }
                                            });
                                }
                            }
                        }
                    });
        }
        else if (totalQuantity == 0 && !"services".equalsIgnoreCase(productType)) {
            Toast.makeText(DetailedActivity.this, "Order quantity must be more than zero", Toast.LENGTH_SHORT).show();
        } else if(!"services".equalsIgnoreCase(productType)){
            if (viewAllModel != null) {
                cartMap.put("img_url",viewAllModel.getImg_url());
                cartMap.put("productName", viewAllModel.getName());
            }

            cartMap.put("Price", price.getText().toString());
            cartMap.put("Date", saveCurrentDate);
            cartMap.put("Time", saveCurrentTime);
            cartMap.put("totalQuantity", quantity.getText().toString());
            cartMap.put("totalPrice", totalprice.getText().toString());

            firestore.collection("CurrentUser")
                    .document(auth.getCurrentUser().getUid())
                    .collection("AddToCart")
                    .whereEqualTo("productName", viewAllModel.getName())
                    .get()
                    .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<QuerySnapshot> task) {
                            if (task.isSuccessful()) {
                                boolean productExists = false;
                                for (QueryDocumentSnapshot document : task.getResult()) {
                                    // If the product exists in the cart, update its quantity
                                    productExists = true;
                                    int existingQuantity = Integer.parseInt(document.get("totalQuantity").toString());
                                    int newQuantity = existingQuantity + totalQuantity;
                                    if(newQuantity > 10){
                                        Toast.makeText(DetailedActivity.this, "You can only buy maximum 10 units in a order", Toast.LENGTH_SHORT).show();
                                    }else {
                                        document.getReference().update("totalQuantity", String.valueOf(newQuantity))
                                                .addOnCompleteListener(new OnCompleteListener<Void>() {
                                                    @Override
                                                    public void onComplete(@NonNull Task<Void> task) {
                                                        Toast.makeText(DetailedActivity.this, "Added To Cart", Toast.LENGTH_SHORT).show();
                                                        finish();
                                                    }
                                                });
                                    }
                                }
                                if (!productExists) {
                                    firestore.collection("CurrentUser")
                                            .document(auth.getCurrentUser().getUid())
                                            .collection("AddToCart")
                                            .add(cartMap)
                                            .addOnCompleteListener(new OnCompleteListener<DocumentReference>() {
                                                @Override
                                                public void onComplete(@NonNull Task<DocumentReference> task) {
                                                    Toast.makeText(DetailedActivity.this, "Added To Cart", Toast.LENGTH_SHORT).show();
                                                    finish();
                                                }
                                            });
                                }
                            }
                        }
                    });


        }
    }

    // Create a method to update the total price based on quantity and price
    private void updateTotalPrice() {
        int itemPrice = 0;

        // Check if viewAllModel or popularModel is not null
        if (viewAllModel != null) {
            try {
                itemPrice = Integer.parseInt(viewAllModel.getPrice());
            } catch (NumberFormatException e) {
                // Handle parsing error
            }
        }

        totalPrice = itemPrice * totalQuantity;
        totalprice.setText(toString().valueOf(totalPrice));
    }

}