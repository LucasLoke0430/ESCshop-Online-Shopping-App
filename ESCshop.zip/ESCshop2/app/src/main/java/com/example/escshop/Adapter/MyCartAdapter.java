package com.example.escshop.Adapter;

import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.navigation.NavController;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.escshop.Model.MyCartModel;
import com.example.escshop.Model.ViewAllModel;
import com.example.escshop.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.List;

public class MyCartAdapter extends RecyclerView.Adapter<MyCartAdapter.ViewHolder> {

    Context context;
    List<MyCartModel> myCartModelList;
    FirebaseFirestore firestore;
    FirebaseAuth auth;
    NavController navController;
    private boolean isClickInProgress = false;



    public MyCartAdapter(Context context, List<MyCartModel> myCartModelList, NavController navController) {
        this.context = context;
        this.myCartModelList = myCartModelList;
        this.navController = navController;
        firestore = FirebaseFirestore.getInstance();
        auth = FirebaseAuth.getInstance();
    }


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.my_cart_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        MyCartModel cartModel = myCartModelList.get(position);

        if (cartModel != null) {
            Glide.with(context).load(cartModel.getImg_url()).into(holder.cartView);
            holder.name.setText(cartModel.getProductName());
            holder.subprice.setText(cartModel.getPrice());
            holder.quantity.setText(cartModel.getTotalQuantity());

            if ("services".equalsIgnoreCase(cartModel.getType())) {
                holder.minusCart.setEnabled(true);
                holder.minusCart.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if (!isClickInProgress) {
                            isClickInProgress = true;

                            // Perform the removal from the database and notify data changes
                            removeFromDatabase(cartModel);
                            notifyItemChanged(holder.getAdapterPosition());
                            notifyDataSetChanged();

                            // Reset the flag after a short delay (e.g., 500 milliseconds)
                            new Handler().postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    isClickInProgress = false;
                                }
                            }, 500);
                        }
                    }
                });
                holder.plusCart.setEnabled(false);
            } else {
                holder.minusCart.setEnabled(true); // Enable the minus button
                holder.plusCart.setEnabled(true); // Enable the plus button
                holder.minusCart.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        handleMinusButtonClick(cartModel, holder);
                    }
                });

                holder.plusCart.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        handlePlusButtonClick(cartModel, holder);
                    }
                });

            }

        }
    }

    private void handleMinusButtonClick(MyCartModel cartModel, ViewHolder holder) {
        int currentQuantity = Integer.parseInt(cartModel.getTotalQuantity());
        int totalPrice = Integer.parseInt(cartModel.getPrice());
        if (currentQuantity > 0) {
            currentQuantity--;
            cartModel.setTotalQuantity(String.valueOf(currentQuantity));
            totalPrice = totalPrice * currentQuantity;
            notifyItemChanged(holder.getAdapterPosition());
            updateTotalQuantityInFirestore(cartModel, currentQuantity);
            updateTotalPriceInFirestore(cartModel, totalPrice);
            if (currentQuantity <= 0) {
                removeFromDatabase(cartModel);
                navController.navigate(R.id.nav_mycart);
            } else {
                updateTotalQuantityInFirestore(cartModel, currentQuantity);
            }
        }
    }

    private void handlePlusButtonClick(MyCartModel cartModel, ViewHolder holder) {
        int currentQuantity = Integer.parseInt(cartModel.getTotalQuantity());
        int totalPrice = Integer.parseInt(cartModel.getPrice());
        if (currentQuantity < 10) {
            currentQuantity++;
            cartModel.setTotalQuantity(String.valueOf(currentQuantity));
            totalPrice = totalPrice * currentQuantity;
            notifyItemChanged(holder.getAdapterPosition());
            updateTotalQuantityInFirestore(cartModel, currentQuantity);
            updateTotalPriceInFirestore(cartModel, totalPrice);
        } else {
            Toast.makeText(context, "You can only buy a maximum of 10 units in an order", Toast.LENGTH_SHORT).show();
            updateTotalQuantityInFirestore(cartModel, currentQuantity);
            notifyItemChanged(holder.getAdapterPosition());
        }
    }


    private void updateTotalPriceInFirestore(MyCartModel cartModel, int totalPrice) {
        firestore.collection("CurrentUser").document(auth.getCurrentUser().getUid())
                .collection("AddToCart")
                .document(cartModel.getDocumentId())
                .update("totalPrice", String.valueOf(totalPrice))
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            // Successfully updated in Firestore
                        } else {
                            // Handle the error
                        }
                    }
                });
    }
    private void updateTotalQuantityInFirestore(MyCartModel cartModel, int currentQuantity) {
        firestore.collection("CurrentUser").document(auth.getCurrentUser().getUid())
                .collection("AddToCart")
                .document(cartModel.getDocumentId())
                .update("totalQuantity", String.valueOf(currentQuantity))
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            // Successfully updated in Firestore
                        } else {
                            // Handle the error
                        }
                    }
                });
    }

    private void removeFromDatabase(MyCartModel cartModel) {
        firestore.collection("CurrentUser")
                .document(auth.getCurrentUser().getUid())
                .collection("AddToCart")
                .document(cartModel.getDocumentId())
                .delete()
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            int position = myCartModelList.indexOf(cartModel);
                            myCartModelList.remove(position);
                            notifyItemRemoved(position);
                        } else {
                            // Handle the error
                        }
                    }
                });
    }

    @Override
    public int getItemCount() {
        return myCartModelList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView cartView;
        TextView name, subprice, quantity, minusCart, plusCart;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            cartView = itemView.findViewById(R.id.pic);
            name = itemView.findViewById(R.id.titleTxtCart);
            subprice = itemView.findViewById(R.id.unitPrice);
            quantity = itemView.findViewById(R.id.numberItemTxt);
            minusCart = itemView.findViewById(R.id.minusCartBtn);
            plusCart = itemView.findViewById(R.id.plusCartBtn);
        }
    }
}
