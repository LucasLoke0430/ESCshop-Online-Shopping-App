package com.example.escshop.ui.home;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavController;
import androidx.navigation.fragment.NavHostFragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.escshop.Activity.ViewAllActivity;
import com.example.escshop.Adapter.HomeAdapter;
import com.example.escshop.Adapter.PopularAdapter;
import com.example.escshop.Adapter.ViewAllAdapter;
import com.example.escshop.Model.HomeCategory;
import com.example.escshop.Model.PopularModel;
import com.example.escshop.Model.ViewAllModel;
import com.example.escshop.MyCartFragment;
import com.example.escshop.R;
import com.example.escshop.databinding.FragmentHomeBinding;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class HomeFragment extends Fragment {

    ScrollView scrollView;
    ProgressBar progressBar;
    RecyclerView popularRec,homeCatRec, allProductRec;
    FirebaseFirestore db;
    EditText search_box;
    LinearLayout home, cart, order, profile;
    private List<ViewAllModel> viewAllModelList;
    private RecyclerView recyclerViewSearch;
    private ViewAllAdapter viewAllAdapter;
    //Category
    List<HomeCategory> categoryList;
    HomeAdapter homeAdapter;
    NavController navController;

    //Popular Item
    PopularAdapter popularAdapter;
    List<PopularModel> popularModelList;
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        View root = inflater.inflate(R.layout.fragment_home, container,false);
        db = FirebaseFirestore.getInstance();

        popularRec = root.findViewById(R.id.pop_rec);
        homeCatRec = root.findViewById(R.id.cate_rec);
        allProductRec = root.findViewById(R.id.all_product_rec);
        scrollView = root.findViewById(R.id.scrollviewhome);
        progressBar = root.findViewById(R.id.progressbarhome);
        navController = NavHostFragment.findNavController(this);

        home = root.findViewById(R.id.homeBtn);
        cart = root.findViewById(R.id.cartBtn);
        order = root.findViewById(R.id.orderBtn);
        profile = root.findViewById(R.id.profileBtn);

        progressBar.setVisibility(View.VISIBLE);
        scrollView.setVisibility(View.GONE);

        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navController.navigate(R.id.nav_home);
            }
        });

        cart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navController.navigate(R.id.nav_mycart);
            }
        });

        order.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navController.navigate(R.id.nav_myorder);
            }
        });

        profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navController.navigate(R.id.nav_profile);
            }
        });





        //Popular items
        popularRec.setLayoutManager(new LinearLayoutManager(getActivity(),RecyclerView.HORIZONTAL,false));
        popularModelList = new ArrayList<>();
        popularAdapter = new PopularAdapter(getActivity(),popularModelList);
        popularRec.setAdapter(popularAdapter);

        db.collection("Product")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot document : task.getResult()) {

                                PopularModel popularModel = document.toObject(PopularModel.class);
                                popularModelList.add(popularModel);
                                popularAdapter.notifyDataSetChanged();

                                progressBar.setVisibility(View.GONE);
                                scrollView.setVisibility(View.VISIBLE);
                            }
                        } else {

                            Toast.makeText(getActivity(),"Error"+task.getException(),Toast.LENGTH_SHORT).show();

                        }
                    }
                });

        //Category items
        homeCatRec.setLayoutManager(new LinearLayoutManager(getActivity(),RecyclerView.HORIZONTAL,false));
        categoryList = new ArrayList<>();
        homeAdapter = new HomeAdapter(getActivity(),categoryList);
        homeCatRec.setAdapter(homeAdapter);

        db.collection("Category")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot document : task.getResult()) {

                                HomeCategory homeCategory = document.toObject(HomeCategory.class);
                                categoryList.add(homeCategory);
                                homeAdapter.notifyDataSetChanged();

                            }
                        } else {

                            Toast.makeText(getActivity(),"Error"+task.getException(),Toast.LENGTH_SHORT).show();

                        }
                    }
                });



        recyclerViewSearch = root.findViewById(R.id.search_rec);
        search_box = root.findViewById(R.id.search_box);
        viewAllModelList = new ArrayList<>();
        viewAllAdapter = new ViewAllAdapter(getContext(),viewAllModelList);
        recyclerViewSearch.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerViewSearch.setAdapter(viewAllAdapter);
        recyclerViewSearch.setHasFixedSize(true);
        search_box.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {

                if (editable.toString().isEmpty()){
                    viewAllAdapter.notifyDataSetChanged();
                }else{

                    searchProduct(editable.toString());
                }
            }
        });

        allProductRec.setLayoutManager(new LinearLayoutManager(getActivity(),RecyclerView.HORIZONTAL,false));
        viewAllModelList = new ArrayList<>();
        viewAllAdapter = new ViewAllAdapter(getActivity(),viewAllModelList);
        allProductRec.setAdapter(viewAllAdapter);

        db.collection("AllProduct")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot document : task.getResult()) {

                                ViewAllModel viewAllModel = document.toObject(ViewAllModel.class);
                                viewAllModelList.add(viewAllModel);
                                viewAllAdapter.notifyDataSetChanged();

                            }
                        } else {

                            Toast.makeText(getActivity(),"Error"+task.getException(),Toast.LENGTH_SHORT).show();

                        }
                    }
                });

        return root;
    }


    private void searchProduct(String query) {
        if (!query.isEmpty()) {
            // Convert the query to lowercase (or uppercase)
            final String lowercaseQuery = query.toLowerCase();

            db.collection("AllProduct")
                    .get()
                    .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<QuerySnapshot> task) {
                            if (task.isSuccessful() && task.getResult() != null) {
                                viewAllModelList.clear();
                                for (DocumentSnapshot doc : task.getResult().getDocuments()) {
                                    // Get the name field from Firestore in lowercase (or uppercase)
                                    String name = doc.getString("name").toLowerCase(); // or .toUpperCase()

                                    // Check if the lowercase (or uppercase) name contains the lowercase query
                                    if (name != null && name.contains(lowercaseQuery)) {
                                        ViewAllModel viewAllModel = doc.toObject(ViewAllModel.class);
                                        viewAllModelList.add(viewAllModel);
                                    }
                                }
                                viewAllAdapter.notifyDataSetChanged();
                            } else {
                                Log.e("Firestore", "Error getting documents: " + task.getException());
                            }
                        }
                    });
        }
    }
    }