// MapActivity.java
package com.example.escshop.Activity;

import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.escshop.Adapter.PlaceAutoSuggestAdapter;
import com.example.escshop.R;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.libraries.places.api.model.AutocompleteSessionToken;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class MapActivity extends AppCompatActivity implements OnMapReadyCallback {

    private GoogleMap myMap;
    AutoCompleteTextView autoCompleteTextView;
    TextView resultText;
    LatLng selectedLoc;
    String selectedLocation;
    Button confirmBut;
    FirebaseFirestore firestore;
    FirebaseAuth auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map);
        autoCompleteTextView = findViewById(R.id.autoCompleteTextView);
        resultText = findViewById(R.id.resultsTextView);
        confirmBut = findViewById(R.id.confirmButton);
        firestore = FirebaseFirestore.getInstance();
        auth = FirebaseAuth.getInstance();
        autoCompleteTextView.setAdapter(new PlaceAutoSuggestAdapter(MapActivity.this, android.R.layout.simple_list_item_1));

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);

        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }

        autoCompleteTextView.setOnItemClickListener((parent, view, position, id) -> {
            selectedLocation = (String) parent.getItemAtPosition(position);
            if (selectedLocation != null) {
                // Display the selected location in resultTextView
                resultText.setText("Selected Location: " + selectedLocation);

                // Convert the selected location to LatLng
                selectedLoc = getLocationFromAddress(selectedLocation);

                if (selectedLoc != null && myMap != null) {
                    myMap.clear();
                    myMap.moveCamera(CameraUpdateFactory.newLatLngZoom(selectedLoc, 15f));

                    myMap.addMarker(new MarkerOptions()
                            .position(selectedLoc)
                            .title(selectedLocation));
                }
            }
        });

        confirmBut.setOnClickListener(view -> {
            if (selectedLocation != null && selectedLoc != null) {
                storeLocationInFirestore(selectedLocation, selectedLoc.latitude, selectedLoc.longitude);
            }else {
                Toast.makeText(getApplicationContext(),"Please enter an address", Toast.LENGTH_SHORT).show();
            }
        });

    }

    private void storeLocationInFirestore(String selectedLocation, double latitude, double longitude) {
        Map<String, Object> locationData = new HashMap<>();
        locationData.put("name", selectedLocation);
        locationData.put("latitude", latitude);
        locationData.put("longitude", longitude);

        String userId = FirebaseAuth.getInstance().getCurrentUser().getUid();

        CollectionReference userAddressCollection = firestore.collection("CurrentUser").document(userId).collection("Address");

        // Check if the user already has an address document
        userAddressCollection.get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                QuerySnapshot querySnapshot = task.getResult();
                if (querySnapshot != null && !querySnapshot.isEmpty()) {
                    // User already has an address document, update it (you can use the first document assuming there is only one)
                    DocumentSnapshot addressDocument = querySnapshot.getDocuments().get(0);
                    userAddressCollection.document(addressDocument.getId())
                            .set(locationData)
                            .addOnSuccessListener(aVoid -> {
                                navigateToMyCartFragment();
                            })
                            .addOnFailureListener(e -> {
                                // Handle errors
                                Toast.makeText(MapActivity.this, "Error updating location: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                            });
                } else {
                    // User doesn't have an existing address document, create a new one
                    userAddressCollection
                            .add(locationData)
                            .addOnSuccessListener(documentReference -> {
                                navigateToMyCartFragment();
                            })
                            .addOnFailureListener(e -> {
                                // Handle errors
                                Toast.makeText(MapActivity.this, "Error storing location: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                            });
                }
            } else {
                // Handle errors
                Toast.makeText(MapActivity.this, "Error checking existing address: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void navigateToMyCartFragment() {

        String fragmentToNavigateTo = "CartFragment";

        Intent intent = new Intent(MapActivity.this, MainActivity.class);
        intent.putExtra("fragmentToNavigateTo", fragmentToNavigateTo);
        startActivity(intent);
        finish();
    }


    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        myMap = googleMap;

        LatLng malaysia = new LatLng(3.067344542176038, 101.60383027110795);
        myMap.addMarker(new MarkerOptions().position(malaysia).title("Sunway University"));
        myMap.moveCamera(CameraUpdateFactory.newLatLngZoom(malaysia, 15f));

        // Enable user interaction with the map
        myMap.getUiSettings().setZoomControlsEnabled(true);
        myMap.getUiSettings().setMapToolbarEnabled(true);
        myMap.setOnMapClickListener(latLng -> {

        });

    }
    private LatLng getLocationFromAddress(String addressStr) {
        Geocoder geocoder = new Geocoder(this);
        List<Address> addresses;

        try {
            addresses = geocoder.getFromLocationName(addressStr, 1);

            if (addresses != null && !addresses.isEmpty()) {
                Address address = addresses.get(0);
                return new LatLng(address.getLatitude(), address.getLongitude());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }




}
