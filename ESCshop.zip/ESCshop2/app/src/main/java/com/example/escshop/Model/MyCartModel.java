package com.example.escshop.Model;

import java.io.Serializable;

public class MyCartModel implements Serializable{

    String productName, Price, totalQuantity, img_url, type;
    String totalPrice;
    String Date, Time;
    String documentId;

    public MyCartModel() {
    }

    public MyCartModel(String productName, String price, String totalQuantity, String img_url, String totalPrice, String date, String time,String type) {
        this.productName = productName;
        Price = price;
        this.totalQuantity = totalQuantity;
        this.img_url = img_url;
        this.totalPrice = totalPrice;
        this.type = type;
        Date = date;
        Time = time;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getDocumentId() {
        return documentId;
    }

    public void setDocumentId(String documentId) {
        this.documentId = documentId;
    }

    public String getDate() {
        return Date;
    }

    public void setDate(String date) {
        Date = date;
    }

    public String getTime() {
        return Time;
    }

    public void setTime(String time) {
        Time = time;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getPrice() {
        return Price;
    }

    public void setPrice(String price) {
        Price = price;
    }

    public String getTotalQuantity() {
        return totalQuantity;
    }

    public void setTotalQuantity(String totalQuantity) {
        this.totalQuantity = totalQuantity;
    }

    public String getImg_url() {
        return img_url;
    }

    public void setImg_url(String img_url) {
        this.img_url = img_url;
    }

    public String getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(String totalPrice) {
        this.totalPrice = totalPrice;
    }
}
