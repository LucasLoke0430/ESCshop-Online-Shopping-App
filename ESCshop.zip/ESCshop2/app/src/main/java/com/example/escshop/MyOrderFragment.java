package com.example.escshop;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.fragment.NavHostFragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.escshop.Activity.MainActivity;
import com.example.escshop.Adapter.OrderAdapter;
import com.example.escshop.Model.OrderModel;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;

public class MyOrderFragment extends Fragment {
    FirebaseFirestore firestore;
    FirebaseAuth auth;
    RecyclerView recyclerView;
    List<OrderModel> orderModelList;
    OrderAdapter orderAdapter;
    ImageView goback, superman, progressbar;
    TextView deliverytext;
    LinearLayout home, cart, order, profile;
    NavController navController;

    public MyOrderFragment() {

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_my_order, container, false);

        firestore = FirebaseFirestore.getInstance();
        auth = FirebaseAuth.getInstance();
        recyclerView = root.findViewById(R.id.recyclerViewOrders);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));

        superman = root.findViewById(R.id.superman);
        progressbar = root.findViewById(R.id.progressbar);
        deliverytext = root.findViewById(R.id.deliverytext);
        goback = root.findViewById(R.id.gobackorder);
        home = root.findViewById(R.id.homeBtn);
        cart = root.findViewById(R.id.cartBtn);
        order = root.findViewById(R.id.orderBtn);
        profile = root.findViewById(R.id.profileBtn);

        goback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NavHostFragment.findNavController(MyOrderFragment.this).navigate(R.id.nav_home);
            }
        });

        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navController.navigate(R.id.nav_home);
            }
        });

        cart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navController.navigate(R.id.nav_mycart);
            }
        });

        order.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navController.navigate(R.id.nav_myorder);
            }
        });

        profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navController.navigate(R.id.nav_profile);
            }
        });

        orderModelList = new ArrayList<>();
        orderAdapter = new OrderAdapter(getActivity(), orderModelList, superman, progressbar, deliverytext);
        recyclerView.setAdapter(orderAdapter);
        recyclerView.setAdapter(orderAdapter);
        navController = NavHostFragment.findNavController(this);

        superman.setVisibility(View.GONE);
        progressbar.setVisibility(View.GONE);
        deliverytext.setText("Checking Order...");

            firestore.collection("CurrentUser").document(auth.getCurrentUser().getUid())
                    .collection("MyOrder").get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<QuerySnapshot> task) {
                            if (task.isSuccessful()) {
                                for (DocumentSnapshot documentSnapshot : task.getResult().getDocuments()) {
                                    String documentId = documentSnapshot.getId();

                                    OrderModel orderModel = documentSnapshot.toObject(OrderModel.class);

                                    orderModel.setDocumentId(documentId);

                                    orderModelList.add(orderModel);
                                    orderAdapter.notifyDataSetChanged();
                                }

                                if (!orderModelList.isEmpty()) {
                                    orderAdapter.notifyDataSetChanged();
                                    superman.setVisibility(View.VISIBLE);
                                    progressbar.setVisibility(View.VISIBLE);
                                    deliverytext.setText("Preparing...");
                                }else{
                                    orderAdapter.notifyDataSetChanged();
                                    superman.setVisibility(View.GONE);
                                    progressbar.setVisibility(View.GONE);
                                    deliverytext.setText("No Order Has Been Made Yet");
                                }
                            }
                        }
                    });
        return root;

    }
}